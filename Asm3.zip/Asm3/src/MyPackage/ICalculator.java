package Asm3.src.MyPackage;
//interface để tính lương cho nhân viên.
interface ICalculator {
    //Lương cơ bản và tăng ca
    long employeeIsBaseSalary = 3000000;
    long overtimeSalary = 200000;
    long managerIsBaseSalary = 5000000;
    //Hàm tính lương cho nhân viên.
    long calculateSalaryOfEmployment();
}
