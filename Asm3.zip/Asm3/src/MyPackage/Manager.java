package Asm3.src.MyPackage;

//Đối tượng là quản lý
public class Manager extends Staff implements ICalculator {
    private String jobTitle;

    public Manager(int id, String name, int age, double coefficientsSalary, String date, String partName, int vacationDays, String jobTitle, long salary) {
        super(id, name, age, coefficientsSalary, date, partName, vacationDays, salary);
        this.jobTitle = jobTitle;
    }
    
    public String getJobTitle() {
        return jobTitle;
    }
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }
    @Override
    public void displayInformation() {
        System.out.println(getId() + 
        "\t" + getName() + 
        "\t" + getAge() + 
        "\t" + getCoefficientsSalary() + 
        "\t\t" + getDate() + 
        "\t\t" + getPartName() + 
        "\t\t" + getVacationDays() +
        "\t\t" + jobTitle);
    }
    @Override
    public long calculateSalaryOfEmployment() {
        return  (long) (managerIsBaseSalary *  getCoefficientsSalary());
    }

}
