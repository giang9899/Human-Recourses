package Asm3.src.MyPackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class HumanResoucres {
    public static ArrayList<Staff> staffList;
    public static ArrayList<Department> departmentList;
    public static Scanner sc = new Scanner(System.in);
    public static int nOfEDepA = 0;
    public static int nOfEDepB = 0;
    public static int nOfEDepC = 0;
    public static long salaryOfBL = 8000000;
    public static long salaryOfPRJ = 5000000;
    public static long salaryOfTECH = 6000000;

    public static void main(String[] args) {
        addEmployees();
        chucNang();
    }
    public static void exit() {
        int exit;
                do {
                    System.out.println("Nhập 0. Exit");
                    exit = sc.nextInt();
                }while(exit != 0);
                chucNang();
    }

    public static void addEmployees() {
        staffList = new ArrayList<Staff>();
        Manager manager1 = new Manager(121, "Nguyen Van G", 23, 5, "12/2/2020", "A", 3, "Business Leader", 0);
        staffList.add(manager1);
        Manager manager2 = new Manager(141, "Nguyen Van G", 23, 1, "12/2/2020", "A", 3, "Project Leader", 0);
        staffList.add(manager2);
        Manager manager3 = new Manager(611, "Nguyen Van G", 23, 2, "12/2/2020", "B", 3, "Technical Leader", 0);
        staffList.add(manager3);
        Manager manager4 = new Manager(171, "Nguyen Van G", 23, 3, "12/2/2020", "C", 3, "Project Leader", 0);
        staffList.add(manager4);
        Manager manager5 = new Manager(111, "Nguyen Van G", 23, 4, "12/2/2020", "C", 3, "Business Leader", 0);
        staffList.add(manager5);
        Manager manager6 = new Manager(117, "Nguyen Van G", 23, 4.5, "12/2/2020", "C", 3, "Technical Leader", 0);
        staffList.add(manager6);

        Employee employee1 = new Employee(11, "Nguyen Van G", 23, 3, "12/2/2020", "A", 3, 4, 0);
        staffList.add(employee1);
        Employee employee2 = new Employee(32, "Nguyen Van C", 24, 3.3, "12/2/2019", "A", 0, 4, 0);
        staffList.add(employee2);
        Employee employee3 = new Employee(56, "Nguyen Van D", 20, 3.0, "12/2/2020", "A", 0, 0, 0);
        staffList.add(employee3);
        Employee employee4 = new Employee(101, "Nguyen Van G", 23, 3.5, "12/2/2020", "B", 3, 4, 0);
        staffList.add(employee4);
        Employee employee5 = new Employee(32, "Nguyen Van C", 24, 3.7, "12/2/2019", "B", 0, 4, 0);
        staffList.add(employee5);
        Employee employee6 = new Employee(546, "Nguyen Van D", 20, 3.1, "12/2/2020", "C", 0, 0, 0);
        staffList.add(employee6);
        Employee employee7 = new Employee(111, "Nguyen Van G", 23, 3.5, "12/2/2020", "C", 3, 4, 0);
        staffList.add(employee7);
        Employee employee8 = new Employee(322, "Nguyen Van C", 24, 3.6, "12/2/2019", "C", 0, 0, 0);
        staffList.add(employee8);
        Employee employee9 = new Employee(58, "Nguyen Van D", 20, 3.2, "12/2/2020", "C", 0, 5, 0);
        staffList.add(employee9);
    }

    public static void countEmployees() {
        for (int i = 0; i < staffList.size(); i++) {
            if (staffList.get(i).getPartName().equals("A")) {
                nOfEDepA++;
            }
            if (staffList.get(i).getPartName().equals("B")) {
                nOfEDepB++;
            }
            if (staffList.get(i).getPartName().equals("C")) {
                nOfEDepC++;
            }
        }
        departmentList = new ArrayList<Department>();

        Department partA = new Department(1, "Bộ phận A", nOfEDepA);
        departmentList.add(partA);
        Department partB = new Department(2, "Bộ phận B", nOfEDepB);
        departmentList.add(partB);
        Department partC = new Department(3, "Bộ phận C", nOfEDepC);
        departmentList.add(partC);
    }

    public static void chucNang() {
        int input;
        do {
            System.out.println("Nhập 1. Hiển thị danh sách nhân viên hiện có trong công ty");
            System.out.println("Nhập 2. Hiển thị các bộ phận trong công ty");
            System.out.println("Nhập 3. Hiển thị các nhân viên theo từng bộ phận");
            System.out.println("Nhập 4. Thêm nhân viên mới vào công ty");
            System.out.println("Nhập 5. Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên");
            System.out.println("Nhập 6. Hiển thị bảng lương của nhân viên toàn công ty");
            System.out.println("Nhập 7. Hiển thị bảng lương của nhân viên theo thứ tự tăng dần");
            System.out.println("Nhập 8. Hiển thị bảng lương của nhân viên theo thứ tự giảm");
            System.out.println("Nhập 0. Exit");
            input = sc.nextInt();
        } while (input < 0 || input > 8);
        if (input == 1) {
            showList();
        } else if (input == 2) {
            showDepartments();
        } else if (input == 3) {
            showEmployees();
        } else if (input == 4) {
            addNewEmployee();
        } else if (input == 5) {
            searchEmployees();
        } else if (input == 6) {
            showSalaryOfEmployees();
        } else if (input == 7) {
            salaryIncrease();
        } else if (input == 8) {
            salaryDecrease();
        } else if (input == 0) {
            System.out.println("Goodbye!");
        }
    }

    public static void showList() {
        for (Staff staff : staffList) {
            staff.displayInformation();
        }
        exit();
    }

    public static void showDepartments() {
        countEmployees();
        for (int i = 0; i < departmentList.size(); i++) {
            if (departmentList.get(i).getIdPart() == 1) {
                System.out.println(departmentList.get(i).toString());
            } else if (departmentList.get(i).getIdPart() == 2) {
                System.out.println(departmentList.get(i).toString());
            } else if (departmentList.get(i).getIdPart() == 3) {
                System.out.println(departmentList.get(i).toString());
            }
        }
       exit();
    }

    public static void showEmployees() {
        countEmployees();
        for (int i = 0; i < departmentList.size(); i++) {
            if (departmentList.get(i).getIdPart() == 1) {
                System.out.println(departmentList.get(i).toString());
                System.out.println(
                        "Quản Lý \nID\tHọ Và Tên\tTuổi\tHệ số lương\tNgày vào cty\t\tBộ phận\t\tSố ngày nghỉ\tChức danh");
                for (int j = 0; j < staffList.size(); j++) {
                    if (staffList.get(j).getPartName().equals("A")) {
                        if (staffList.get(j) instanceof Manager) {
                            ((Manager) staffList.get(j)).displayInformation();
                        }
                    }
                }
                System.out.println(
                        "Nhân Viên \nID\tHọ Và Tên\tTuổi\tHệ số lương\tNgày vào cty\t\tBộ phận\t\tSố ngày nghỉ\tGiờ làm thêm");
                for (int j = 0; j < staffList.size(); j++) {
                    if (staffList.get(j).getPartName().equals("A")) {
                        if (staffList.get(j) instanceof Employee) {
                            ((Employee) staffList.get(j)).displayInformation();
                        }
                    }
                }
            } else if (departmentList.get(i).getIdPart() == 2) {
                System.out.println(departmentList.get(i).toString());
                System.out.println(
                        "Quản Lý \nID\tHọ Và Tên\tTuổi\tHệ số lương\tNgày vào cty\t\tBộ phận\t\tSố ngày nghỉ\tChức danh");
                for (int j = 0; j < staffList.size(); j++) {
                    if (staffList.get(j).getPartName().equals("B")) {
                        if (staffList.get(j) instanceof Manager) {
                            ((Manager) staffList.get(j)).displayInformation();
                        }
                    }
                }
                System.out.println(
                        "Nhân Viên \nID\tHọ Và Tên\tTuổi\tHệ số lương\tNgày vào cty\t\tBộ phận\t\tSố ngày nghỉ\tGiờ làm thêm");
                for (int j = 0; j < staffList.size(); j++) {
                    if (staffList.get(j).getPartName().equals("B")) {
                        if (staffList.get(j) instanceof Employee) {
                            ((Employee) staffList.get(j)).displayInformation();
                        }
                    }
                }
            } else if (departmentList.get(i).getIdPart() == 3) {
                System.out.println(departmentList.get(i).toString());
                System.out.println(
                        "Quản Lý \nID\tHọ Và Tên\tTuổi\tHệ số lương\tNgày vào cty\t\tBộ phận\t\tSố ngày nghỉ\tChức danh");
                for (int j = 0; j < staffList.size(); j++) {
                    if (staffList.get(j).getPartName().equals("C")) {
                        if (staffList.get(j) instanceof Manager) {
                            ((Manager) staffList.get(j)).displayInformation();
                        }
                    }
                }
                System.out.println(
                        "Nhân Viên \nID\tHọ Và Tên\tTuổi\tHệ số lương\tNgày vào cty\t\tBộ phận\t\tSố ngày nghỉ\tGiờ làm thêm");
                for (int j = 0; j < staffList.size(); j++) {
                    if (staffList.get(j).getPartName().equals("C")) {
                        if (staffList.get(j) instanceof Employee) {
                            ((Employee) staffList.get(j)).displayInformation();
                        }
                    }
                }
            }
        }
        exit();
    }

    public static int id;
    public static String name = "";
    public static int age;
    public static double cSalary;
    public static String date;
    public static int days;
    public static int overtime;
    public static String jobTitle;

    public static void add_New_Manager() {
        System.out.print("ID: ");
        id = sc.nextInt();
        System.out.print("Name: ");
        sc.nextLine();
        name = sc.nextLine();
        System.out.print("Age: ");
        age = sc.nextInt();
        System.out.print("Coefficients salary: ");
        cSalary = sc.nextDouble();
        System.out.print("Entry date(d/m/y): ");
        date = sc.next();
        System.out.print("Vacation days: ");
        days = sc.nextInt();
        System.out.print("JobTitle: ");
        sc.nextLine();
        jobTitle = sc.nextLine();
    }

    public static void add_New_Employee() {
        System.out.print("ID: ");
        id = sc.nextInt();
        System.out.print("Name: ");
        sc.nextLine();
        name = sc.nextLine();
        System.out.print("Age: ");
        age = sc.nextInt();
        System.out.print("Coefficients salary: ");
        cSalary = sc.nextDouble();
        System.out.print("Entry date(d/m/y): ");
        date = sc.next();
        System.out.print("Vacation days: ");
        days = sc.nextInt();
        System.out.print("OverTime: ");
        overtime = sc.nextInt();
    }

    public static void addNewEmployee() {
        int answer;
        do {
            System.out.print("Nhập 1. Thêm quản lý");
            System.out.print("\tNhập 2. Thêm nhân viên");
            System.out.println("\tNhập 0. Exit");
            answer = sc.nextInt();
        } while (answer < 0 || answer > 2);
        if (answer == 1) {
            int answer1;
            do {
                System.out.print("Nhập 1. Thêm vào bộ phận A");
                System.out.print("\tNhập 2. Thêm vào bộ phận B");
                System.out.print("\tNhập 3. Thêm vào bộ phận C");
                System.out.println("\tNhập 0. Exit");
                answer1 = sc.nextInt();
            } while (answer < 0 || answer > 3);
            if (answer1 == 1) {
                add_New_Manager();
                Manager manager = new Manager(id, name, age, cSalary, date, "A", days, jobTitle, 0);
                staffList.add(manager);
                exit();
            } else if (answer1 == 2) {
                add_New_Manager();
                Manager manager = new Manager(id, name, age, cSalary, date, "B", days, jobTitle, 0);
                staffList.add(manager);
                exit();
            } else if (answer1 == 3) {
                add_New_Manager();
                Manager manager = new Manager(id, name, age, cSalary, date, "C", days, jobTitle, 0);
                staffList.add(manager);
                exit();
            } else if (answer1 == 0) {
                addNewEmployee();
            }
        } else if (answer == 2) {
            int answer1;
            do {
                System.out.print("Nhập 1. Thêm vào bộ phận A");
                System.out.print("\tNhập 2. Thêm vào bộ phận B");
                System.out.print("\tNhập 3. Thêm vào bộ phận C");
                System.out.println("\tNhập 0. Exit");
                answer1 = sc.nextInt();
            } while (answer < 0 || answer > 3);
            if (answer1 == 1) {
                add_New_Employee();
                Employee employee = new Employee(id, name, age, cSalary, date, "A", days, overtime, 0);
                staffList.add(employee);
                exit();
            } else if (answer1 == 2) {
                add_New_Employee();
                Employee employee = new Employee(id, name, age, cSalary, date, "B", days, overtime, 0);
                staffList.add(employee);
                exit();
            } else if (answer1 == 3) {
                add_New_Employee();
                Employee employee = new Employee(id, name, age, cSalary, date, "C", days, overtime, 0);
                staffList.add(employee);
                exit();
            } else if (answer1 == 0) {
                add_New_Employee();
            }
        } else if (answer == 0) {
            chucNang();
        }

    }

    public static void searchEmployees() {
        int answer;
        do {
            System.out.println("Nhập 1. Tìm nhân viên theo ID \t Nhập 2. Tìm nhân viên theo tên \t Nhập 0. Exit");
            answer = sc.nextInt();
        } while (answer < 0 || answer > 2);
        if (answer == 1) {
            System.out.print("Nhập Id: ");
            int searchById = sc.nextInt();
            for (int i = 0; i < staffList.size(); i++) {
                if (searchById == staffList.get(i).getId()) {
                    staffList.get(i).displayInformation();
                }
            }
            searchEmployees();
        } else if (answer == 2) {
            System.out.print("Nhập tên: ");
            sc.nextLine();
            String searchByName = sc.nextLine().trim();
            System.out.println(searchByName);
            for (int i = 0; i < staffList.size(); i++) {
                if (staffList.get(i).getName().equals(searchByName)) {
                    staffList.get(i).displayInformation();
                }
            }
            searchEmployees();
        } else if (answer == 0) {
            chucNang();
        }
    }

    public static void showSalaryOfEmployees() {
        for (int i = 0; i < staffList.size(); i++) {
            long salary = 0;
            if (staffList.get(i) instanceof Manager) {
                if (((Manager) staffList.get(i)).getJobTitle().equals("Business Leader")) {
                    salary = (((Manager) staffList.get(i)).calculateSalaryOfEmployment() + salaryOfBL);
                } else if (((Manager) staffList.get(i)).getJobTitle().equals("Project Leader")) {
                    salary = (((Manager) staffList.get(i)).calculateSalaryOfEmployment() + salaryOfPRJ);
                } else if (((Manager) staffList.get(i)).getJobTitle().equals("Technical Leader")) {
                    salary = (((Manager) staffList.get(i)).calculateSalaryOfEmployment() + salaryOfTECH);
                }
            }
            if (staffList.get(i) instanceof Employee) {
                salary = ((Employee) staffList.get(i)).calculateSalaryOfEmployment();

            }
            System.out.println(staffList.get(i).getId() + "\t" + staffList.get(i).getName() + "\t" + salary);
        }
        exit();
    }

    public static void setSalary() {
        for (int i = 0; i < staffList.size(); i++) {
            long salary = 0;
            if (staffList.get(i) instanceof Manager) {
                if (((Manager) staffList.get(i)).getJobTitle().equals("Business Leader")) {
                    salary = (((Manager) staffList.get(i)).calculateSalaryOfEmployment() + salaryOfBL);
                } else if (((Manager) staffList.get(i)).getJobTitle().equals("Project Leader")) {
                    salary = (((Manager) staffList.get(i)).calculateSalaryOfEmployment() + salaryOfPRJ);
                } else if (((Manager) staffList.get(i)).getJobTitle().equals("Technical Leader")) {
                    salary = (((Manager) staffList.get(i)).calculateSalaryOfEmployment() + salaryOfTECH);
                }
            }
            if (staffList.get(i) instanceof Employee) {
                salary = ((Employee) staffList.get(i)).calculateSalaryOfEmployment();
            }
            staffList.get(i).setSalary(salary);
        }
    }

    public static void salaryIncrease() {
        setSalary();
        Collections.sort(staffList, new Comparator<Staff>() {
            @Override
            public int compare(Staff salary1, Staff salary2) {
                if (salary1.getSalary() < salary2.getSalary()) {
                    return -1;
                } else {
                    if (salary1.getSalary() == salary2.getSalary()) {
                        return 0;
                    } else {
                        return 1;
                    }
                }
            }
        });
        for (int i = 0; i < staffList.size(); i++) {
            System.out.println(
                    staffList.get(i).getId() + "\t" + staffList.get(i).getName() + "\t" + staffList.get(i).getSalary());
        }
        exit();
    }

    public static void salaryDecrease() {
        setSalary();
        Collections.sort(staffList, new Comparator<Staff>() {
            @Override
            public int compare(Staff salary1, Staff salary2) {
                if (salary1.getSalary() < salary2.getSalary()) {
                    return 1;
                } else {
                    if (salary1.getSalary() == salary2.getSalary()) {
                        return 0;
                    } else {
                        return -1;
                    }
                }
            }
        });
        for (int i = 0; i < staffList.size(); i++) {
            System.out.println(
                    staffList.get(i).getId() + "\t" + staffList.get(i).getName() + "\t" + staffList.get(i).getSalary());
        }
        exit();
    }
}
