package Asm3.src.MyPackage;

public class Employee extends Staff implements ICalculator {
    private double overtime;
   
    public Employee(int id, String name, int age, double coefficientSalary, String date, 
    String partName, int vacationDays, int overtime, long salary) {
        super(id, name, age, coefficientSalary, date, partName, vacationDays, salary);
        this.overtime = overtime;
    }
    
    public double getOvertime() {
        return overtime;
    }
    public void setOvertime(int overtime) {
        this.overtime = overtime;
    }
    @Override
    public void displayInformation() {
        System.out.println(getId() + 
        "\t" + getName() + 
        "\t" + getAge() + 
        "\t" + getCoefficientsSalary() + 
        "\t\t" + getDate() + 
        "\t\t" + getPartName() + 
        "\t\t" + getVacationDays() +
        "\t\t" + overtime);
    }
    @Override
    public long calculateSalaryOfEmployment() {
        return (long) (getCoefficientsSalary() * employeeIsBaseSalary + overtime * overtimeSalary);
    }
}
