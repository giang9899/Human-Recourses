package Asm3.src.MyPackage;
//Tạo class bộ phận của công ty
public class Department {
    //State
    private int idPart;
    private String namePart;
    private int nOfEmployees;
    //khởi tạo đối tượng
    public Department(int idPart, String namePart, int nOfEmployees) {
        this.idPart = idPart;
        this.namePart = namePart;
        this.nOfEmployees = nOfEmployees;
    }
//getter setter thuộc tính của đối tượng.
    public int getIdPart() {
        return idPart;
    }
    public int getNOfEmployees() {
        return nOfEmployees;
    }
    public String getNamePart() {
        return namePart;
    }
    public void setNOfEmployees(int nOfEmployees) {
        this.nOfEmployees = nOfEmployees;
    }
    public void setNamePart(String namePart) {
        this.namePart = namePart;
    }
    public void setIdPart(int idPart) {
        this.idPart = idPart;
    }
    //in ra thông tin về bộ phận.
    public String toString() {
        String str =
        "\t\t\t\t\t" + namePart  + 
        "\n\t\t\t\t-------------------------" + 
        "\n\t\tID bộ phận: " + idPart + "\t\t\t\tNhân lực của bộ phận: " + nOfEmployees;

        return str;
    }
}
