package Asm3.src.MyPackage;

public abstract class Staff {
    private int id;
    private String name;
    private int age;
    private double coefficientsSalary;
    private String date;
    private String partName;
    private int vacationDays;
    private long salary;

   public Staff(int id, String name, int age, double coefficientsSalary, String date, String partName, int vacationDays, long salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.coefficientsSalary = coefficientsSalary;
        this.date = date;
        this.partName = partName;
        this.vacationDays = vacationDays;
        this.salary = salary;
   }
   public int getId() {
       return id;
   }
   public void setId(int id) {
       this.id = id;
   }
   public String getName() {
       return name;
   }
   public void setName(String name) {
       this.name = name;
   }
   public int getAge() {
       return age;
   }
   public void setAge(int age) {
       this.age = age;
   }
   public double getCoefficientsSalary() {
       return coefficientsSalary;
   }
   public void setCoefficientsSalary(double coefficientsSalary) {
       this.coefficientsSalary = coefficientsSalary;
   }
   public String getDate() {
       return date;
   }
   public void setDate(String date) {
       this.date = date;
   }
   public String getPartName() {
       return partName;
   }
   public void setPartName(String partName) {
       this.partName = partName;
   }
   public int getVacationDays() {
       return vacationDays;
   }
   public void setVacationDays(int vacationDays) {
       this.vacationDays = vacationDays;
   }
   public long getSalary() {
       return salary;
   }
   public void setSalary(long salary) {
       this.salary = salary;
   }

   public abstract void displayInformation();



}
